import { Component, ElementRef, ViewChild } from '@angular/core';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

@Component({
  selector: 'app-pdf-generator',
  templateUrl: './pdf-generator.component.html',
  styleUrls: ['./pdf-generator.component.css']
})
export class PdfGeneratorComponent {
  @ViewChild('pdfContent') pdfContent!: ElementRef;

  async generatePDF() {
    const pdf = new jsPDF('p', 'mm', 'a4');

    const content = this.pdfContent.nativeElement;

    await html2canvas(content).then(canvas => {
      const imgData = canvas.toDataURL('image/png');
      const imgWidth = 190;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      pdf.addImage(imgData, 'PNG', 10, 10, imgWidth, imgHeight);
      pdf.save("MinHtetSoe.pdf"); // Auto-download the PDF
    });
  }
}
