import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PdfGeneratorComponent } from './pdf-generator/pdf-generator.component';  // Import PdfGeneratorComponent

const routes: Routes = [
  { path: '', component: PdfGeneratorComponent },  // Set as default or directly route to PDF generator
  // or specify a custom route like this:
  // { path: 'generate-pdf', component: PdfGeneratorComponent },  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
